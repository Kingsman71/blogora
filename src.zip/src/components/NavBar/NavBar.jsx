import React, { useState } from 'react';
import { Link, NavLink } from 'react-router-dom';
import './NavBar.css';

const NavBar = () => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const toggleMobileMenu = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen);
  };

  const closeMobileMenu = () => {
    setIsMobileMenuOpen(false);
  };

  return (
    <nav className="navbar">
      <Link to="/" className="navbar-brand" onClick={closeMobileMenu}>
        BlogApp
      </Link>

      <button className="mobile-menu-button" onClick={toggleMobileMenu}>
        <span className="menu-icon"></span>
      </button>

      <div className={`navbar-links ${isMobileMenuOpen ? 'active' : ''}`}>
        <NavLink to="/" onClick={closeMobileMenu}>
          Home
        </NavLink>
        <NavLink to="/create" onClick={closeMobileMenu}>
          Create Post
        </NavLink>
        <NavLink to="/about" onClick={closeMobileMenu}>
          About
        </NavLink>
      </div>
    </nav>
  );
};

export default NavBar;